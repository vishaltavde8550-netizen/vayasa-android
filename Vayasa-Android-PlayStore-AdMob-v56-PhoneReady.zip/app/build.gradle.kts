plugins {
    id("com.android.application")
}

val adMode = providers.gradleProperty("adMode").orElse("test").get().lowercase()
val useProductionAds = adMode == "production"

android {
    namespace = "com.vayasa.agelesshealth"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.vayasa.agelesshealth"
        minSdk = 23
        targetSdk = 36
        versionCode = 56
        versionName = "56.0"
        buildConfigField("String", "ADMOB_BANNER_ID", "\"${if (useProductionAds) "ca-app-pub-5342620705450766/7183390365" else "ca-app-pub-3940256099942544/6300978111"}\"")
        manifestPlaceholders["ADMOB_APP_ID"] = if (useProductionAds) {
            "ca-app-pub-5342620705450766~9382178292"
        } else {
            "ca-app-pub-3940256099942544~3347511713"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("androidx.activity:activity:1.11.0")
    implementation("com.google.android.gms:play-services-ads:25.5.0")
    implementation("com.google.android.ump:user-messaging-platform:4.0.0")
}
