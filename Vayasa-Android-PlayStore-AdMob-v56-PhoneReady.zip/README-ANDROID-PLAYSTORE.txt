VAYASA ANDROID / PLAY STORE / ADMOB ONE-SHOT BASE v56

Package: com.vayasa.agelesshealth
Target/Compile SDK: 36 (Android 16)
Google Mobile Ads SDK: 25.5.0
Google UMP SDK: 4.0.0

Web app:
https://vayasa-ageless-health-8550.pages.dev/sign-in

AD MOB MODES
------------
Default build: TEST ads.
Production build: gradle bundleRelease -PadMode=production

TEST IDs:
App ID: ca-app-pub-3940256099942544~3347511713
Banner ID: ca-app-pub-3940256099942544/6300978111

PRODUCTION IDs:
App ID: ca-app-pub-5342620705450766~9382178292
Banner ID: ca-app-pub-5342620705450766/7183390365
Publisher ID for app-ads.txt: pub-5342620705450766

The GitHub Actions workflow builds a release AAB. It is currently unsigned.
A Play Store production upload requires a signed AAB/upload key. Do not commit
keystore files or passwords to the repository.

Cloudflare Worker/D1 is not modified by this Android project.
